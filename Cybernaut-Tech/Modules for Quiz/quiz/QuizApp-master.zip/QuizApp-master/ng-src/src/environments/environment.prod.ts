export const environment = {
  production: true,
  AUTH0_CLIENT_ID: 'YOUR_AUTH0_CLIENT_ID',
  AUTH0_DOMAIN: 'YOUR_AUTH0_DOMAIN'
};
